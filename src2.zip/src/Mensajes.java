


package biblioteca;

import java.util.ArrayList;

public class Mensajes {


	public void menuprincipal() {
		System.out.println("");
		System.out.println("<1> Ingresar libro");
		System.out.println("<2> Buscar libro por el isnb");
		System.out.println("<3> venta de libro");
		System.out.println("<4> Mostrar los tres libros mas caros");
		System.out.println("<5> Mostrar todos los libros");
		System.out.println("<0> Salir del programa");
		System.out.println(" ");
		System.out.println("Ingrese opci�n: ");
	}

	
}